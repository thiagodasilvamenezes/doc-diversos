# Modelo conceitual SIADL — adaptação CNPJ alfanumérico GECPA10

## Alteração incorporada

O modelo conceitual foi ajustado para tratar o documento do cliente como **identificador fiscal CPF/CNPJ**, e não como atributo puramente numérico. Como a solução parte de uma DDL já existente, a coluna única de CPF/CNPJ foi preservada por compatibilidade estrutural, mas sua semântica foi atualizada para suportar CNPJ alfanumérico.

## Decisão conceitual

- A entidade `CLIENTE` mantém um identificador técnico próprio (`NU_CLIENTE`).
- O atributo de identificação fiscal passa a ser representado como `CO_CPF_CNPJ`, com unicidade associada ao tipo de pessoa.
- O atributo `IC_TIPO_PESSOA` continua distinguindo pessoa física (`F`) e pessoa jurídica (`J`).
- A especialização conceitual `CLIENTE -> PESSOA_FISICA / PESSOA_JURIDICA` permanece válida como regra de negócio, ainda que o modelo físico opte por materialização em tabela única por desempenho e compatibilidade com a DDL existente.
- O relacionamento direto `CLIENTE -> INTERACAO_ATENDIMENTO` foi removido, pois a interação é derivável por `CLIENTE -> ATENDIMENTO -> INTERACAO_ATENDIMENTO`.

## Regra de negócio

A identificação fiscal do cliente deve ser única por tipo de pessoa. Para preservar eficiência nas pesquisas, o valor deve ser persistido normalizado, sem máscara, em 14 posições:

- CPF: valor numérico normalizado para 14 posições, com zeros à esquerda;
- CNPJ: valor alfanumérico de 14 posições, conforme orientação GECPA10.

As consultas devem usar predicado direto sobre `IC_TIPO_PESSOA` e `CO_CPF_CNPJ`, sem `CAST`, `CONVERT`, `RIGHT`, `REPLACE` ou outras funções no `WHERE`.

## Arquivos

- `03_diagrama_conceitual_siadl_cnpj_gepca.mmd`: diagrama conceitual em Mermaid;
- `modelo_conceitual_siadl_cnpj_gepca.md`: especificação textual da alteração.
