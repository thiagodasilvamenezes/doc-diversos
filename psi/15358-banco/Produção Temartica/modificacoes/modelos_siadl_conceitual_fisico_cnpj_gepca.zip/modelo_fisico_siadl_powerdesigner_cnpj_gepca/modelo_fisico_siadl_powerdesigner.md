# Modelo físico ideal SIADL para PowerDesigner — CNPJ alfanumérico GECPA10

Alias utilizado: `SDL` (substituir pelo alias oficial do SIADL antes da validação formal).


Esta versão incorpora a adaptação do identificador fiscal do cliente ao novo formato de CNPJ alfanumérico. Como o SIADL parte de uma DDL existente com uma coluna única para CPF/CNPJ, o modelo preserva a compatibilidade estrutural, mas altera a classe e o tipo físico da coluna para `CO_CPF_CNPJ CHAR(14)`, mantendo `IC_TIPO_PESSOA` para distinguir pessoa física e jurídica e criando índice por `IC_TIPO_PESSOA, CO_CPF_CNPJ` para preservar a eficiência das pesquisas sem `CAST`/`CONVERT` no predicado.


## 1. Tabelas

| Table Code | Table Name | Classificação | Volume atual | Crescimento | Particionamento | Comment |
|---|---|---|---|---|---|---|
| `SDLTB001_CLIENTE` | CLIENTE | Mestre | ~100 mi | 10% a.a. | Não particionada inicialmente; avaliar por crescimento e manutenção. | Armazena a identificação cadastral do cliente pessoa física ou jurídica atendido pelo SIADL, com situação, segmento e identificador fiscal CPF/CNPJ mantido em coluna única por compatibilidade com a DDL existente e ajustado ao CNPJ alfanumérico conforme orientação GECPA10. |
| `SDLTB002_CONTA` | CONTA | Mestre | ~500 mi | 20% a.a. | Avaliar particionamento por DT_ABERTURA; nesta proposta mantém PK simples e índices por cliente. | Armazena a conta vinculada ao cliente, utilizada como referência para transações financeiras, limites e consultas operacionais do SIADL. |
| `SDLTB003_CANAL` | CANAL | Domínio | ~10 | Estável | Não particionada. | Domínio corporativo/local do SIADL para canais de origem ou atendimento utilizados em transações e atendimentos, evitando texto livre e divergência de grafia. |
| `SDLTB004_ATENDIMENTO` | ATENDIMENTO | Transacional | ~800 mi | 20% a.m. | Particionada mensalmente por DH_ABERTURA. | Registra a solicitação, reclamação ou serviço aberto por cliente no SIADL, com canal, tipo, prioridade, situação e datas de abertura e fechamento. |
| `SDLTB005_INTERACAO_ATEND` | INTERACAO_ATENDIMENTO | Operacional/Histórica | ~1 bi | 20% a.m. | Particionada mensalmente por DH_INTERACAO. | Registra cada interação ocorrida durante o ciclo de vida de um atendimento, preservando a sequência temporal das tratativas realizadas. |
| `SDLTB006_TRANSACAO` | TRANSACAO | Transacional | ~4 bi | 30% a.m. | Particionada mensalmente por DH_TRANSACAO. | Registra a operação financeira associada a uma conta, canal e tipo de transação, mantendo o estado corrente da operação para consulta OLTP. |
| `SDLTB007_TRANSACAO_HISTORICO` | TRANSACAO_HISTORICO | Histórica | ~10 bi | 30% a.m. | Particionada mensalmente por DH_EVENTO. | Registra, de forma append-only, os eventos de alteração de situação de uma transação, compondo trilha histórica e de auditoria negocial. |
| `SDLTB008_DISPOSITIVO_CLIENTE` | DISPOSITIVO_CLIENTE | Operacional | ~150 mi | 10% a.a. | Não particionada inicialmente; avaliar por DT_VINCULO. | Armazena dispositivo vinculado ao cliente para uso em autenticação, segurança e antifraude, com tipo, sistema operacional, hash e situação. |
| `SDLTB009_LIMITE_CONTA` | LIMITE_CONTA | Temporal/Operacional | ~1 bi | 20% a.a. | Avaliar particionamento por DT_INICIO_VIGENCIA; regra de vigente exige validação AD/DBA. | Armazena limites operacionais por conta e tipo de limite, com vigência negocial controlada por datas de início e fim. |
| `SDLTB010_TIPO_TRANSACAO` | TIPO_TRANSACAO | Domínio | Baixo | Estável | Não particionada. | Domínio dos tipos de transação reconhecidos pelo SIADL, incluindo transação original, estorno, ajuste e reversão, quando aplicável. |
| `SDLTB011_SITUACAO_TRANSACAO` | SITUACAO_TRANSACAO | Domínio | Baixo | Estável | Não particionada. | Domínio das situações possíveis de uma transação no SIADL, utilizado no estado corrente e no histórico de eventos. |
| `SDLTB012_TIPO_ATENDIMENTO` | TIPO_ATENDIMENTO | Domínio | Baixo | Estável | Não particionada. | Domínio dos tipos de atendimento processados pelo SIADL. |
| `SDLTB013_SITUACAO_ATENDIMENTO` | SITUACAO_ATENDIMENTO | Domínio | Baixo | Estável | Não particionada. | Domínio das situações do ciclo de vida do atendimento, como aberto, em tratamento, concluído ou cancelado. |
| `SDLTB014_PRIORIDADE_ATEND` | PRIORIDADE_ATENDIMENTO | Domínio | Baixo | Estável | Não particionada. | Domínio das prioridades aplicáveis aos atendimentos do SIADL. |
| `SDLTB015_TIPO_CONTA` | TIPO_CONTA | Domínio | Baixo | Estável | Não particionada. | Domínio dos tipos de conta reconhecidos pelo SIADL. |
| `SDLTB016_SITUACAO_CONTA` | SITUACAO_CONTA | Domínio | Baixo | Estável | Não particionada. | Domínio das situações de conta utilizadas pelo SIADL. |
| `SDLTB017_SITUACAO_CLIENTE` | SITUACAO_CLIENTE | Domínio | Baixo | Estável | Não particionada. | Domínio das situações cadastrais do cliente no SIADL. |
| `SDLTB018_SEGMENTO_CLIENTE` | SEGMENTO_CLIENTE | Domínio | Baixo | Estável | Não particionada. | Domínio dos segmentos de cliente utilizados para classificação cadastral e operacional no SIADL. |
| `SDLTB019_TIPO_DISPOSITIVO` | TIPO_DISPOSITIVO | Domínio | Baixo | Estável | Não particionada. | Domínio dos tipos de dispositivo vinculáveis a cliente para autenticação e segurança. |
| `SDLTB020_SISTEMA_OPERACIONAL` | SISTEMA_OPERACIONAL | Domínio | Baixo | Estável | Não particionada. | Domínio dos sistemas operacionais associados aos dispositivos de cliente. |
| `SDLTB021_TIPO_LIMITE` | TIPO_LIMITE | Domínio | Baixo | Estável | Não particionada. | Domínio dos tipos de limite operacional de conta. |
| `SDLTB022_ORIGEM_EVENTO` | ORIGEM_EVENTO | Domínio | Baixo | Estável | Não particionada. | Domínio das origens de eventos registrados no histórico de transações. |
| `SDLTB023_TIPO_CANAL` | TIPO_CANAL | Domínio | Baixo | Estável | Não particionada. | Domínio dos tipos de canal utilizados para classificar os canais do SIADL. |
| `SDLTB024_SITUACAO_CANAL` | SITUACAO_CANAL | Domínio | Baixo | Estável | Não particionada. | Domínio das situações de canal utilizadas no controle de canais ativos e inativos. |

## 2. Colunas por tabela


### SDLTB001_CLIENTE — CLIENTE

Armazena a identificação cadastral do cliente pessoa física ou jurídica atendido pelo SIADL, com situação, segmento e identificador fiscal CPF/CNPJ mantido em coluna única por compatibilidade com a DDL existente e ajustado ao CNPJ alfanumérico conforme orientação GECPA10.

| Coluna | Tipo | Nulo | PK | Identity | FK | Check | Comentário | Notes |
|---|---|---|---|---|---|---|---|---|
| `NU_CLIENTE` | `BIGINT` | N | S | S |  |  | Número identificador técnico e estável do cliente no SIADL, utilizado como chave primária e referência nas relações com conta, atendimento e dispositivo. | Chave substituta; não utilizar CPF/CNPJ como PK. |
| `NO_CLIENTE` | `VARCHAR(150)` | N | N | N |  |  | Nome ou razão social do cliente conforme cadastro utilizado pelo SIADL. | Dado pessoal; classificar no PowerDesigner. |
| `CO_CPF_CNPJ` | `CHAR(14)` | N | N | N |  | Ver CT_SDLTB001_1 | Código do identificador fiscal do cliente, contendo CPF ou CNPJ sem máscara, normalizado em 14 posições. Para CPF, o valor deve ser completado com zeros à esquerda; para CNPJ, admite composição alfanumérica conforme orientação GECPA10. | Coluna única preservada por compatibilidade com a DDL existente e consumidores legados; não compõe a PK. Pesquisas devem usar valor normalizado e predicado direto, sem CAST/CONVERT. |
| `IC_TIPO_PESSOA` | `CHAR(1)` | N | N | N |  | IC_TIPO_PESSOA IN ('F','J') | Indicador do tipo de pessoa do cliente, com F para pessoa física e J para pessoa jurídica. | Implementa fisicamente a especialização PF/PJ em tabela única. |
| `DH_CADASTRO` | `DATETIME2(3)` | N | N | N |  |  | Data e hora em que o cliente foi cadastrado ou disponibilizado para uso no SIADL. | Substitui uso indevido de TIMESTAMP. |
| `CO_SITUACAO_CLIENTE` | `TINYINT` | N | N | N | SDLTB017_SITUACAO_CLIENTE.CO_SITUACAO_CLIENTE |  | Código da situação cadastral do cliente, conforme domínio controlado de situações de cliente. | Substitui texto livre de situação. |
| `CO_SEGMENTO_CLIENTE` | `TINYINT` | N | N | N | SDLTB018_SEGMENTO_CLIENTE.CO_SEGMENTO_CLIENTE |  | Código do segmento do cliente, conforme domínio controlado de segmentos utilizados pelo SIADL. | Substitui texto livre de segmento. |
| `DH_INCLUSAO_REGISTRO` | `DATETIME2(3)` | N | N | N |  |  | Data e hora em que o registro foi incluído na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `DH_ALTERACAO_REGISTRO` | `DATETIME2(3)` | S | N | N |  |  | Data e hora da última alteração do registro na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `CO_USUARIO_INCLUSAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela inclusão do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `CO_USUARIO_ALTERACAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela última alteração do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `VS_CONTROLE_CONCORRENCIA` | `ROWVERSION` | N | N | N |  |  | Valor de controle de concorrência gerado pelo SQL Server para apoiar atualização otimista do registro de cliente. | Uso correto do ROWVERSION; não representa data/hora. |

### SDLTB002_CONTA — CONTA

Armazena a conta vinculada ao cliente, utilizada como referência para transações financeiras, limites e consultas operacionais do SIADL.

| Coluna | Tipo | Nulo | PK | Identity | FK | Check | Comentário | Notes |
|---|---|---|---|---|---|---|---|---|
| `NU_CONTA` | `BIGINT` | N | S | S |  |  | Número identificador técnico e estável da conta no SIADL. | Chave substituta. |
| `NU_CLIENTE` | `BIGINT` | N | N | N | SDLTB001_CLIENTE.NU_CLIENTE |  | Número identificador do cliente titular ou vinculado à conta no SIADL. | FK para cliente. |
| `NU_CONTA_BANCARIA` | `VARCHAR(30)` | N | N | N |  |  | Número negocial da conta utilizado nos processos operacionais e consultas do SIADL. | Chave candidata; unique. |
| `CO_TIPO_CONTA` | `TINYINT` | N | N | N | SDLTB015_TIPO_CONTA.CO_TIPO_CONTA |  | Código do tipo de conta, conforme domínio controlado de tipos de conta. | Substitui texto livre. |
| `DT_ABERTURA` | `DATE` | N | N | N |  |  | Data de abertura da conta no contexto de negócio do SIADL. | Usar DATE quando não houver necessidade de hora. |
| `CO_SITUACAO_CONTA` | `TINYINT` | N | N | N | SDLTB016_SITUACAO_CONTA.CO_SITUACAO_CONTA |  | Código da situação da conta, conforme domínio controlado de situações de conta. | Substitui texto livre. |
| `DH_INCLUSAO_REGISTRO` | `DATETIME2(3)` | N | N | N |  |  | Data e hora em que o registro foi incluído na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `DH_ALTERACAO_REGISTRO` | `DATETIME2(3)` | S | N | N |  |  | Data e hora da última alteração do registro na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `CO_USUARIO_INCLUSAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela inclusão do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `CO_USUARIO_ALTERACAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela última alteração do registro. | Preencher conforme padrão de auditoria da aplicação. |

### SDLTB003_CANAL — CANAL

Domínio corporativo/local do SIADL para canais de origem ou atendimento utilizados em transações e atendimentos, evitando texto livre e divergência de grafia.

| Coluna | Tipo | Nulo | PK | Identity | FK | Check | Comentário | Notes |
|---|---|---|---|---|---|---|---|---|
| `NU_CANAL` | `TINYINT` | N | S | N |  |  | Número identificador do canal de origem ou atendimento utilizado pelo SIADL. | Domínio de baixa cardinalidade. |
| `NO_CANAL` | `VARCHAR(80)` | N | N | N |  |  | Nome do canal utilizado para identificar a origem de atendimento ou transação no SIADL. | Evitar texto livre em tabelas transacionais. |
| `CO_TIPO_CANAL` | `TINYINT` | N | N | N | SDLTB023_TIPO_CANAL.CO_TIPO_CANAL |  | Código do tipo de canal, conforme domínio controlado de tipos de canal. | Classifica canal. |
| `CO_SITUACAO_CANAL` | `TINYINT` | N | N | N | SDLTB024_SITUACAO_CANAL.CO_SITUACAO_CANAL |  | Código da situação do canal, conforme domínio controlado de situações de canal. | Permite inativação sem exclusão. |
| `DH_INCLUSAO_REGISTRO` | `DATETIME2(3)` | N | N | N |  |  | Data e hora em que o registro foi incluído na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `DH_ALTERACAO_REGISTRO` | `DATETIME2(3)` | S | N | N |  |  | Data e hora da última alteração do registro na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `CO_USUARIO_INCLUSAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela inclusão do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `CO_USUARIO_ALTERACAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela última alteração do registro. | Preencher conforme padrão de auditoria da aplicação. |

### SDLTB004_ATENDIMENTO — ATENDIMENTO

Registra a solicitação, reclamação ou serviço aberto por cliente no SIADL, com canal, tipo, prioridade, situação e datas de abertura e fechamento.

| Coluna | Tipo | Nulo | PK | Identity | FK | Check | Comentário | Notes |
|---|---|---|---|---|---|---|---|---|
| `DH_ABERTURA` | `DATETIME2(3)` | N | S | N |  |  | Data e hora de abertura do atendimento no SIADL. | Coluna de particionamento mensal. |
| `NU_ATENDIMENTO` | `BIGINT` | N | S | S |  |  | Número identificador do atendimento no SIADL, único dentro da chave composta com a data e hora de abertura. | PK composta para alinhamento ao particionamento. |
| `NU_CLIENTE` | `BIGINT` | N | N | N | SDLTB001_CLIENTE.NU_CLIENTE |  | Número identificador do cliente que abriu ou está vinculado ao atendimento. | FK para cliente. |
| `NU_CANAL` | `TINYINT` | N | N | N | SDLTB003_CANAL.NU_CANAL |  | Número identificador do canal de origem do atendimento, substituindo texto livre de canal. | FK para domínio de canal. |
| `CO_TIPO_ATENDIMENTO` | `TINYINT` | N | N | N | SDLTB012_TIPO_ATENDIMENTO.CO_TIPO_ATENDIMENTO |  | Código do tipo de atendimento, conforme domínio controlado. | Ajuda governança e consulta por tipo. |
| `DH_FECHAMENTO` | `DATETIME2(3)` | S | N | N |  | DH_FECHAMENTO IS NULL OR DH_FECHAMENTO >= DH_ABERTURA | Data e hora de fechamento do atendimento, quando o ciclo de atendimento for concluído ou cancelado. | NULL indica atendimento ainda aberto. |
| `CO_SITUACAO_ATENDIMENTO` | `TINYINT` | N | N | N | SDLTB013_SITUACAO_ATENDIMENTO.CO_SITUACAO_ATENDIMENTO |  | Código da situação corrente do atendimento, conforme domínio controlado. | Usar histórico/interações para eventos. |
| `CO_PRIORIDADE_ATENDIMENTO` | `TINYINT` | N | N | N | SDLTB014_PRIORIDADE_ATEND.CO_PRIORIDADE_ATENDIMENTO |  | Código da prioridade atribuída ao atendimento, conforme domínio controlado. | Substitui texto livre. |
| `DH_INCLUSAO_REGISTRO` | `DATETIME2(3)` | N | N | N |  |  | Data e hora em que o registro foi incluído na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `DH_ALTERACAO_REGISTRO` | `DATETIME2(3)` | S | N | N |  |  | Data e hora da última alteração do registro na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `CO_USUARIO_INCLUSAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela inclusão do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `CO_USUARIO_ALTERACAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela última alteração do registro. | Preencher conforme padrão de auditoria da aplicação. |

### SDLTB005_INTERACAO_ATEND — INTERACAO_ATENDIMENTO

Registra cada interação ocorrida durante o ciclo de vida de um atendimento, preservando a sequência temporal das tratativas realizadas.

| Coluna | Tipo | Nulo | PK | Identity | FK | Check | Comentário | Notes |
|---|---|---|---|---|---|---|---|---|
| `DH_INTERACAO` | `DATETIME2(3)` | N | S | N |  |  | Data e hora em que a interação do atendimento ocorreu no SIADL. | Coluna de particionamento mensal. |
| `NU_INTERACAO_ATENDIMENTO` | `BIGINT` | N | S | S |  |  | Número identificador técnico da interação de atendimento no SIADL. | PK composta para alinhamento ao particionamento. |
| `DH_ABERTURA` | `DATETIME2(3)` | N | N | N | SDLTB004_ATENDIMENTO.DH_ABERTURA |  | Data e hora de abertura do atendimento ao qual a interação pertence. | Compõe FK com NU_ATENDIMENTO. |
| `NU_ATENDIMENTO` | `BIGINT` | N | N | N | SDLTB004_ATENDIMENTO.NU_ATENDIMENTO |  | Número identificador do atendimento ao qual a interação pertence. | Compõe FK com DH_ABERTURA. |
| `CO_TIPO_INTERACAO` | `TINYINT` | N | N | N |  |  | Código do tipo de interação realizada no atendimento, conforme domínio a ser formalizado pelo AD se houver variedade controlada. | Se necessário, criar tabela de domínio específica. |
| `CO_ORIGEM_INTERACAO` | `TINYINT` | N | N | N |  |  | Código da origem da interação registrada no atendimento. | Se necessário, criar tabela de domínio específica. |
| `DE_CONTEUDO_RESUMIDO` | `VARCHAR(1000)` | S | N | N |  |  | Resumo textual da interação registrada, limitado ao conteúdo necessário para consulta operacional e auditoria negocial. | Evitar dados excessivos; avaliar sigilo e retenção. |
| `DH_INCLUSAO_REGISTRO` | `DATETIME2(3)` | N | N | N |  |  | Data e hora em que o registro foi incluído na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `DH_ALTERACAO_REGISTRO` | `DATETIME2(3)` | S | N | N |  |  | Data e hora da última alteração do registro na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `CO_USUARIO_INCLUSAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela inclusão do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `CO_USUARIO_ALTERACAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela última alteração do registro. | Preencher conforme padrão de auditoria da aplicação. |

### SDLTB006_TRANSACAO — TRANSACAO

Registra a operação financeira associada a uma conta, canal e tipo de transação, mantendo o estado corrente da operação para consulta OLTP.

| Coluna | Tipo | Nulo | PK | Identity | FK | Check | Comentário | Notes |
|---|---|---|---|---|---|---|---|---|
| `DH_TRANSACAO` | `DATETIME2(3)` | N | S | N |  |  | Data e hora em que a transação foi realizada no SIADL. | Coluna de particionamento mensal. |
| `NU_TRANSACAO` | `BIGINT` | N | S | S |  |  | Número identificador da transação no SIADL, único dentro da chave composta com a data e hora da transação. | PK composta para alinhamento ao particionamento. |
| `NU_CONTA` | `BIGINT` | N | N | N | SDLTB002_CONTA.NU_CONTA |  | Número identificador da conta à qual a transação está associada. | FK para conta. |
| `NU_CANAL` | `TINYINT` | N | N | N | SDLTB003_CANAL.NU_CANAL |  | Número identificador do canal de origem da transação. | FK para canal. |
| `VR_TRANSACAO` | `DECIMAL(17,2)` | N | N | N |  | VR_TRANSACAO > 0 | Valor monetário da transação, registrado com precisão decimal e sem sinal negativo. | Estorno é evento transacional próprio vinculado à transação original. |
| `CO_TIPO_TRANSACAO` | `TINYINT` | N | N | N | SDLTB010_TIPO_TRANSACAO.CO_TIPO_TRANSACAO |  | Código do tipo de transação, conforme domínio controlado, incluindo tipos específicos de estorno, ajuste ou reversão quando aplicável. | Substitui texto livre. |
| `CO_SITUACAO_TRANSACAO` | `TINYINT` | N | N | N | SDLTB011_SITUACAO_TRANSACAO.CO_SITUACAO_TRANSACAO |  | Código da situação corrente da transação, conforme domínio controlado. | Histórico completo em TRANSACAO_HISTORICO. |
| `DH_TRANSACAO_ORIGINAL` | `DATETIME2(3)` | S | N | N | SDLTB006_TRANSACAO.DH_TRANSACAO |  | Data e hora da transação original relacionada, quando a transação atual representar estorno, ajuste ou reversão. | Compõe autorrelacionamento opcional. |
| `NU_TRANSACAO_ORIGINAL` | `BIGINT` | S | N | N | SDLTB006_TRANSACAO.NU_TRANSACAO |  | Número da transação original relacionada, quando a transação atual representar estorno, ajuste ou reversão. | Compõe autorrelacionamento opcional. |
| `DH_INCLUSAO_REGISTRO` | `DATETIME2(3)` | N | N | N |  |  | Data e hora em que o registro foi incluído na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `DH_ALTERACAO_REGISTRO` | `DATETIME2(3)` | S | N | N |  |  | Data e hora da última alteração do registro na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `CO_USUARIO_INCLUSAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela inclusão do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `CO_USUARIO_ALTERACAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela última alteração do registro. | Preencher conforme padrão de auditoria da aplicação. |

### SDLTB007_TRANSACAO_HISTORICO — TRANSACAO_HISTORICO

Registra, de forma append-only, os eventos de alteração de situação de uma transação, compondo trilha histórica e de auditoria negocial.

| Coluna | Tipo | Nulo | PK | Identity | FK | Check | Comentário | Notes |
|---|---|---|---|---|---|---|---|---|
| `DH_EVENTO` | `DATETIME2(3)` | N | S | N |  |  | Data e hora em que ocorreu o evento de alteração de situação da transação. | Coluna de particionamento mensal. |
| `NU_TRANSACAO_HISTORICO` | `BIGINT` | N | S | S |  |  | Número identificador técnico do evento histórico da transação. | PK composta para alinhamento ao particionamento. |
| `DH_TRANSACAO` | `DATETIME2(3)` | N | N | N | SDLTB006_TRANSACAO.DH_TRANSACAO |  | Data e hora da transação à qual o evento histórico pertence. | Compõe FK com NU_TRANSACAO. |
| `NU_TRANSACAO` | `BIGINT` | N | N | N | SDLTB006_TRANSACAO.NU_TRANSACAO |  | Número da transação à qual o evento histórico pertence. | Compõe FK com DH_TRANSACAO. |
| `CO_SITUACAO_ANTERIOR` | `TINYINT` | S | N | N | SDLTB011_SITUACAO_TRANSACAO.CO_SITUACAO_TRANSACAO |  | Código da situação anterior da transação antes do evento registrado. | NULL permitido para evento inicial. |
| `CO_SITUACAO_NOVA` | `TINYINT` | N | N | N | SDLTB011_SITUACAO_TRANSACAO.CO_SITUACAO_TRANSACAO |  | Código da nova situação da transação após o evento registrado. | Domínio de situação. |
| `CO_ORIGEM_EVENTO` | `TINYINT` | N | N | N | SDLTB022_ORIGEM_EVENTO.CO_ORIGEM_EVENTO |  | Código da origem responsável pelo evento de alteração de situação da transação. | Domínio de origem. |
| `DE_EVENTO` | `VARCHAR(300)` | S | N | N |  |  | Descrição complementar do evento histórico, quando necessária para auditoria negocial. | Evitar repetição do nome do evento. |
| `DH_INCLUSAO_REGISTRO` | `DATETIME2(3)` | N | N | N |  |  | Data e hora em que o registro foi incluído na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `DH_ALTERACAO_REGISTRO` | `DATETIME2(3)` | S | N | N |  |  | Data e hora da última alteração do registro na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `CO_USUARIO_INCLUSAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela inclusão do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `CO_USUARIO_ALTERACAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela última alteração do registro. | Preencher conforme padrão de auditoria da aplicação. |

### SDLTB008_DISPOSITIVO_CLIENTE — DISPOSITIVO_CLIENTE

Armazena dispositivo vinculado ao cliente para uso em autenticação, segurança e antifraude, com tipo, sistema operacional, hash e situação.

| Coluna | Tipo | Nulo | PK | Identity | FK | Check | Comentário | Notes |
|---|---|---|---|---|---|---|---|---|
| `NU_DISPOSITIVO_CLIENTE` | `BIGINT` | N | S | S |  |  | Número identificador técnico do dispositivo vinculado ao cliente no SIADL. | Chave substituta. |
| `NU_CLIENTE` | `BIGINT` | N | N | N | SDLTB001_CLIENTE.NU_CLIENTE |  | Número identificador do cliente ao qual o dispositivo está vinculado. | FK para cliente. |
| `CO_TIPO_DISPOSITIVO` | `TINYINT` | N | N | N | SDLTB019_TIPO_DISPOSITIVO.CO_TIPO_DISPOSITIVO |  | Código do tipo de dispositivo vinculado ao cliente. | Domínio controlado. |
| `CO_SISTEMA_OPERACIONAL` | `TINYINT` | S | N | N | SDLTB020_SISTEMA_OPERACIONAL.CO_SISTEMA_OPERACIONAL |  | Código do sistema operacional do dispositivo, quando identificado. | Domínio controlado. |
| `CO_HASH_DISPOSITIVO` | `CHAR(64)` | N | N | N |  |  | Código hash do dispositivo utilizado para identificação técnica sem armazenamento direto de identificador sensível. | Dado sensível/técnico; classificar. |
| `DT_VINCULO` | `DATE` | N | N | N |  |  | Data em que o dispositivo foi vinculado ao cliente no SIADL. | Ciclo de vida do dispositivo. |
| `DT_REVOGACAO` | `DATE` | S | N | N |  | DT_REVOGACAO IS NULL OR DT_REVOGACAO >= DT_VINCULO | Data de revogação do vínculo do dispositivo, quando houver. | NULL indica vínculo vigente. |
| `IC_DISPOSITIVO_ATIVO` | `CHAR(1)` | N | N | N |  | IC_DISPOSITIVO_ATIVO IN ('S','N') | Indicador que informa se o dispositivo está ativo para uso no SIADL, com S para ativo e N para inativo. | Evitar exclusão física. |
| `DH_INCLUSAO_REGISTRO` | `DATETIME2(3)` | N | N | N |  |  | Data e hora em que o registro foi incluído na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `DH_ALTERACAO_REGISTRO` | `DATETIME2(3)` | S | N | N |  |  | Data e hora da última alteração do registro na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `CO_USUARIO_INCLUSAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela inclusão do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `CO_USUARIO_ALTERACAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela última alteração do registro. | Preencher conforme padrão de auditoria da aplicação. |

### SDLTB009_LIMITE_CONTA — LIMITE_CONTA

Armazena limites operacionais por conta e tipo de limite, com vigência negocial controlada por datas de início e fim.

| Coluna | Tipo | Nulo | PK | Identity | FK | Check | Comentário | Notes |
|---|---|---|---|---|---|---|---|---|
| `DT_INICIO_VIGENCIA` | `DATE` | N | S | N |  |  | Data inicial de vigência negocial do limite da conta. | Tempo de negócio, não tempo de sistema. |
| `NU_LIMITE_CONTA` | `BIGINT` | N | S | S |  |  | Número identificador técnico do limite de conta no SIADL. | PK composta para permitir avaliação de particionamento por vigência. |
| `NU_CONTA` | `BIGINT` | N | N | N | SDLTB002_CONTA.NU_CONTA |  | Número identificador da conta à qual o limite está associado. | FK para conta. |
| `CO_TIPO_LIMITE` | `TINYINT` | N | N | N | SDLTB021_TIPO_LIMITE.CO_TIPO_LIMITE |  | Código do tipo de limite operacional da conta. | Domínio controlado. |
| `VR_LIMITE` | `DECIMAL(17,2)` | N | N | N |  | VR_LIMITE >= 0 | Valor monetário do limite operacional da conta para o tipo informado. | Precisão decimal. |
| `DT_FIM_VIGENCIA` | `DATE` | S | N | N |  | DT_FIM_VIGENCIA IS NULL OR DT_FIM_VIGENCIA > DT_INICIO_VIGENCIA | Data final de vigência negocial do limite, sendo nula quando o limite estiver vigente. | Regra de não sobreposição exige validação transacional adicional. |
| `DH_INCLUSAO_REGISTRO` | `DATETIME2(3)` | N | N | N |  |  | Data e hora em que o registro foi incluído na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `DH_ALTERACAO_REGISTRO` | `DATETIME2(3)` | S | N | N |  |  | Data e hora da última alteração do registro na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `CO_USUARIO_INCLUSAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela inclusão do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `CO_USUARIO_ALTERACAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela última alteração do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `VS_CONTROLE_CONCORRENCIA` | `ROWVERSION` | N | N | N |  |  | Valor de controle de concorrência gerado pelo SQL Server para apoiar atualização otimista do limite de conta. | Uso correto do ROWVERSION. |

### SDLTB010_TIPO_TRANSACAO — TIPO_TRANSACAO

Domínio dos tipos de transação reconhecidos pelo SIADL, incluindo transação original, estorno, ajuste e reversão, quando aplicável.

| Coluna | Tipo | Nulo | PK | Identity | FK | Check | Comentário | Notes |
|---|---|---|---|---|---|---|---|---|
| `CO_TIPO_TRANSACAO` | `TINYINT` | N | S | N |  |  | Código que identifica univocamente o domínio tipo transacao no SIADL. | Domínio controlado pelo AD. |
| `NO_TIPO_TRANSACAO` | `VARCHAR(80)` | N | N | N |  |  | Nome do domínio tipo transacao, utilizado para apresentação e entendimento negocial. | Nome sem ambiguidade e alinhado ao glossário. |
| `DE_TIPO_TRANSACAO` | `VARCHAR(300)` | S | N | N |  |  | Descrição complementar do domínio tipo transacao, com finalidade, restrições e exemplos quando necessário. | Evitar tautologia. |
| `IC_ATIVO` | `CHAR(1)` | N | N | N |  | IC_ATIVO IN ('S','N') | Indicador que informa se o domínio está ativo para uso no SIADL, com S para ativo e N para inativo. | Não excluir domínio historicamente utilizado. |
| `DH_INCLUSAO_REGISTRO` | `DATETIME2(3)` | N | N | N |  |  | Data e hora em que o registro foi incluído na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `DH_ALTERACAO_REGISTRO` | `DATETIME2(3)` | S | N | N |  |  | Data e hora da última alteração do registro na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `CO_USUARIO_INCLUSAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela inclusão do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `CO_USUARIO_ALTERACAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela última alteração do registro. | Preencher conforme padrão de auditoria da aplicação. |

### SDLTB011_SITUACAO_TRANSACAO — SITUACAO_TRANSACAO

Domínio das situações possíveis de uma transação no SIADL, utilizado no estado corrente e no histórico de eventos.

| Coluna | Tipo | Nulo | PK | Identity | FK | Check | Comentário | Notes |
|---|---|---|---|---|---|---|---|---|
| `CO_SITUACAO_TRANSACAO` | `TINYINT` | N | S | N |  |  | Código que identifica univocamente o domínio situacao transacao no SIADL. | Domínio controlado pelo AD. |
| `NO_SITUACAO_TRANSACAO` | `VARCHAR(80)` | N | N | N |  |  | Nome do domínio situacao transacao, utilizado para apresentação e entendimento negocial. | Nome sem ambiguidade e alinhado ao glossário. |
| `DE_SITUACAO_TRANSACAO` | `VARCHAR(300)` | S | N | N |  |  | Descrição complementar do domínio situacao transacao, com finalidade, restrições e exemplos quando necessário. | Evitar tautologia. |
| `IC_ATIVO` | `CHAR(1)` | N | N | N |  | IC_ATIVO IN ('S','N') | Indicador que informa se o domínio está ativo para uso no SIADL, com S para ativo e N para inativo. | Não excluir domínio historicamente utilizado. |
| `DH_INCLUSAO_REGISTRO` | `DATETIME2(3)` | N | N | N |  |  | Data e hora em que o registro foi incluído na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `DH_ALTERACAO_REGISTRO` | `DATETIME2(3)` | S | N | N |  |  | Data e hora da última alteração do registro na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `CO_USUARIO_INCLUSAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela inclusão do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `CO_USUARIO_ALTERACAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela última alteração do registro. | Preencher conforme padrão de auditoria da aplicação. |

### SDLTB012_TIPO_ATENDIMENTO — TIPO_ATENDIMENTO

Domínio dos tipos de atendimento processados pelo SIADL.

| Coluna | Tipo | Nulo | PK | Identity | FK | Check | Comentário | Notes |
|---|---|---|---|---|---|---|---|---|
| `CO_TIPO_ATENDIMENTO` | `TINYINT` | N | S | N |  |  | Código que identifica univocamente o domínio tipo atendimento no SIADL. | Domínio controlado pelo AD. |
| `NO_TIPO_ATENDIMENTO` | `VARCHAR(80)` | N | N | N |  |  | Nome do domínio tipo atendimento, utilizado para apresentação e entendimento negocial. | Nome sem ambiguidade e alinhado ao glossário. |
| `DE_TIPO_ATENDIMENTO` | `VARCHAR(300)` | S | N | N |  |  | Descrição complementar do domínio tipo atendimento, com finalidade, restrições e exemplos quando necessário. | Evitar tautologia. |
| `IC_ATIVO` | `CHAR(1)` | N | N | N |  | IC_ATIVO IN ('S','N') | Indicador que informa se o domínio está ativo para uso no SIADL, com S para ativo e N para inativo. | Não excluir domínio historicamente utilizado. |
| `DH_INCLUSAO_REGISTRO` | `DATETIME2(3)` | N | N | N |  |  | Data e hora em que o registro foi incluído na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `DH_ALTERACAO_REGISTRO` | `DATETIME2(3)` | S | N | N |  |  | Data e hora da última alteração do registro na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `CO_USUARIO_INCLUSAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela inclusão do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `CO_USUARIO_ALTERACAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela última alteração do registro. | Preencher conforme padrão de auditoria da aplicação. |

### SDLTB013_SITUACAO_ATENDIMENTO — SITUACAO_ATENDIMENTO

Domínio das situações do ciclo de vida do atendimento, como aberto, em tratamento, concluído ou cancelado.

| Coluna | Tipo | Nulo | PK | Identity | FK | Check | Comentário | Notes |
|---|---|---|---|---|---|---|---|---|
| `CO_SITUACAO_ATENDIMENTO` | `TINYINT` | N | S | N |  |  | Código que identifica univocamente o domínio situacao atendimento no SIADL. | Domínio controlado pelo AD. |
| `NO_SITUACAO_ATENDIMENTO` | `VARCHAR(80)` | N | N | N |  |  | Nome do domínio situacao atendimento, utilizado para apresentação e entendimento negocial. | Nome sem ambiguidade e alinhado ao glossário. |
| `DE_SITUACAO_ATENDIMENTO` | `VARCHAR(300)` | S | N | N |  |  | Descrição complementar do domínio situacao atendimento, com finalidade, restrições e exemplos quando necessário. | Evitar tautologia. |
| `IC_ATIVO` | `CHAR(1)` | N | N | N |  | IC_ATIVO IN ('S','N') | Indicador que informa se o domínio está ativo para uso no SIADL, com S para ativo e N para inativo. | Não excluir domínio historicamente utilizado. |
| `DH_INCLUSAO_REGISTRO` | `DATETIME2(3)` | N | N | N |  |  | Data e hora em que o registro foi incluído na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `DH_ALTERACAO_REGISTRO` | `DATETIME2(3)` | S | N | N |  |  | Data e hora da última alteração do registro na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `CO_USUARIO_INCLUSAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela inclusão do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `CO_USUARIO_ALTERACAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela última alteração do registro. | Preencher conforme padrão de auditoria da aplicação. |

### SDLTB014_PRIORIDADE_ATEND — PRIORIDADE_ATENDIMENTO

Domínio das prioridades aplicáveis aos atendimentos do SIADL.

| Coluna | Tipo | Nulo | PK | Identity | FK | Check | Comentário | Notes |
|---|---|---|---|---|---|---|---|---|
| `CO_PRIORIDADE_ATENDIMENTO` | `TINYINT` | N | S | N |  |  | Código que identifica univocamente o domínio prioridade atend no SIADL. | Domínio controlado pelo AD. |
| `NO_PRIORIDADE_ATENDIMENTO` | `VARCHAR(80)` | N | N | N |  |  | Nome do domínio prioridade atend, utilizado para apresentação e entendimento negocial. | Nome sem ambiguidade e alinhado ao glossário. |
| `DE_PRIORIDADE_ATENDIMENTO` | `VARCHAR(300)` | S | N | N |  |  | Descrição complementar do domínio prioridade atend, com finalidade, restrições e exemplos quando necessário. | Evitar tautologia. |
| `IC_ATIVO` | `CHAR(1)` | N | N | N |  | IC_ATIVO IN ('S','N') | Indicador que informa se o domínio está ativo para uso no SIADL, com S para ativo e N para inativo. | Não excluir domínio historicamente utilizado. |
| `DH_INCLUSAO_REGISTRO` | `DATETIME2(3)` | N | N | N |  |  | Data e hora em que o registro foi incluído na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `DH_ALTERACAO_REGISTRO` | `DATETIME2(3)` | S | N | N |  |  | Data e hora da última alteração do registro na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `CO_USUARIO_INCLUSAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela inclusão do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `CO_USUARIO_ALTERACAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela última alteração do registro. | Preencher conforme padrão de auditoria da aplicação. |

### SDLTB015_TIPO_CONTA — TIPO_CONTA

Domínio dos tipos de conta reconhecidos pelo SIADL.

| Coluna | Tipo | Nulo | PK | Identity | FK | Check | Comentário | Notes |
|---|---|---|---|---|---|---|---|---|
| `CO_TIPO_CONTA` | `TINYINT` | N | S | N |  |  | Código que identifica univocamente o domínio tipo conta no SIADL. | Domínio controlado pelo AD. |
| `NO_TIPO_CONTA` | `VARCHAR(80)` | N | N | N |  |  | Nome do domínio tipo conta, utilizado para apresentação e entendimento negocial. | Nome sem ambiguidade e alinhado ao glossário. |
| `DE_TIPO_CONTA` | `VARCHAR(300)` | S | N | N |  |  | Descrição complementar do domínio tipo conta, com finalidade, restrições e exemplos quando necessário. | Evitar tautologia. |
| `IC_ATIVO` | `CHAR(1)` | N | N | N |  | IC_ATIVO IN ('S','N') | Indicador que informa se o domínio está ativo para uso no SIADL, com S para ativo e N para inativo. | Não excluir domínio historicamente utilizado. |
| `DH_INCLUSAO_REGISTRO` | `DATETIME2(3)` | N | N | N |  |  | Data e hora em que o registro foi incluído na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `DH_ALTERACAO_REGISTRO` | `DATETIME2(3)` | S | N | N |  |  | Data e hora da última alteração do registro na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `CO_USUARIO_INCLUSAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela inclusão do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `CO_USUARIO_ALTERACAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela última alteração do registro. | Preencher conforme padrão de auditoria da aplicação. |

### SDLTB016_SITUACAO_CONTA — SITUACAO_CONTA

Domínio das situações de conta utilizadas pelo SIADL.

| Coluna | Tipo | Nulo | PK | Identity | FK | Check | Comentário | Notes |
|---|---|---|---|---|---|---|---|---|
| `CO_SITUACAO_CONTA` | `TINYINT` | N | S | N |  |  | Código que identifica univocamente o domínio situacao conta no SIADL. | Domínio controlado pelo AD. |
| `NO_SITUACAO_CONTA` | `VARCHAR(80)` | N | N | N |  |  | Nome do domínio situacao conta, utilizado para apresentação e entendimento negocial. | Nome sem ambiguidade e alinhado ao glossário. |
| `DE_SITUACAO_CONTA` | `VARCHAR(300)` | S | N | N |  |  | Descrição complementar do domínio situacao conta, com finalidade, restrições e exemplos quando necessário. | Evitar tautologia. |
| `IC_ATIVO` | `CHAR(1)` | N | N | N |  | IC_ATIVO IN ('S','N') | Indicador que informa se o domínio está ativo para uso no SIADL, com S para ativo e N para inativo. | Não excluir domínio historicamente utilizado. |
| `DH_INCLUSAO_REGISTRO` | `DATETIME2(3)` | N | N | N |  |  | Data e hora em que o registro foi incluído na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `DH_ALTERACAO_REGISTRO` | `DATETIME2(3)` | S | N | N |  |  | Data e hora da última alteração do registro na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `CO_USUARIO_INCLUSAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela inclusão do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `CO_USUARIO_ALTERACAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela última alteração do registro. | Preencher conforme padrão de auditoria da aplicação. |

### SDLTB017_SITUACAO_CLIENTE — SITUACAO_CLIENTE

Domínio das situações cadastrais do cliente no SIADL.

| Coluna | Tipo | Nulo | PK | Identity | FK | Check | Comentário | Notes |
|---|---|---|---|---|---|---|---|---|
| `CO_SITUACAO_CLIENTE` | `TINYINT` | N | S | N |  |  | Código que identifica univocamente o domínio situacao cliente no SIADL. | Domínio controlado pelo AD. |
| `NO_SITUACAO_CLIENTE` | `VARCHAR(80)` | N | N | N |  |  | Nome do domínio situacao cliente, utilizado para apresentação e entendimento negocial. | Nome sem ambiguidade e alinhado ao glossário. |
| `DE_SITUACAO_CLIENTE` | `VARCHAR(300)` | S | N | N |  |  | Descrição complementar do domínio situacao cliente, com finalidade, restrições e exemplos quando necessário. | Evitar tautologia. |
| `IC_ATIVO` | `CHAR(1)` | N | N | N |  | IC_ATIVO IN ('S','N') | Indicador que informa se o domínio está ativo para uso no SIADL, com S para ativo e N para inativo. | Não excluir domínio historicamente utilizado. |
| `DH_INCLUSAO_REGISTRO` | `DATETIME2(3)` | N | N | N |  |  | Data e hora em que o registro foi incluído na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `DH_ALTERACAO_REGISTRO` | `DATETIME2(3)` | S | N | N |  |  | Data e hora da última alteração do registro na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `CO_USUARIO_INCLUSAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela inclusão do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `CO_USUARIO_ALTERACAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela última alteração do registro. | Preencher conforme padrão de auditoria da aplicação. |

### SDLTB018_SEGMENTO_CLIENTE — SEGMENTO_CLIENTE

Domínio dos segmentos de cliente utilizados para classificação cadastral e operacional no SIADL.

| Coluna | Tipo | Nulo | PK | Identity | FK | Check | Comentário | Notes |
|---|---|---|---|---|---|---|---|---|
| `CO_SEGMENTO_CLIENTE` | `TINYINT` | N | S | N |  |  | Código que identifica univocamente o domínio segmento cliente no SIADL. | Domínio controlado pelo AD. |
| `NO_SEGMENTO_CLIENTE` | `VARCHAR(80)` | N | N | N |  |  | Nome do domínio segmento cliente, utilizado para apresentação e entendimento negocial. | Nome sem ambiguidade e alinhado ao glossário. |
| `DE_SEGMENTO_CLIENTE` | `VARCHAR(300)` | S | N | N |  |  | Descrição complementar do domínio segmento cliente, com finalidade, restrições e exemplos quando necessário. | Evitar tautologia. |
| `IC_ATIVO` | `CHAR(1)` | N | N | N |  | IC_ATIVO IN ('S','N') | Indicador que informa se o domínio está ativo para uso no SIADL, com S para ativo e N para inativo. | Não excluir domínio historicamente utilizado. |
| `DH_INCLUSAO_REGISTRO` | `DATETIME2(3)` | N | N | N |  |  | Data e hora em que o registro foi incluído na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `DH_ALTERACAO_REGISTRO` | `DATETIME2(3)` | S | N | N |  |  | Data e hora da última alteração do registro na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `CO_USUARIO_INCLUSAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela inclusão do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `CO_USUARIO_ALTERACAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela última alteração do registro. | Preencher conforme padrão de auditoria da aplicação. |

### SDLTB019_TIPO_DISPOSITIVO — TIPO_DISPOSITIVO

Domínio dos tipos de dispositivo vinculáveis a cliente para autenticação e segurança.

| Coluna | Tipo | Nulo | PK | Identity | FK | Check | Comentário | Notes |
|---|---|---|---|---|---|---|---|---|
| `CO_TIPO_DISPOSITIVO` | `TINYINT` | N | S | N |  |  | Código que identifica univocamente o domínio tipo dispositivo no SIADL. | Domínio controlado pelo AD. |
| `NO_TIPO_DISPOSITIVO` | `VARCHAR(80)` | N | N | N |  |  | Nome do domínio tipo dispositivo, utilizado para apresentação e entendimento negocial. | Nome sem ambiguidade e alinhado ao glossário. |
| `DE_TIPO_DISPOSITIVO` | `VARCHAR(300)` | S | N | N |  |  | Descrição complementar do domínio tipo dispositivo, com finalidade, restrições e exemplos quando necessário. | Evitar tautologia. |
| `IC_ATIVO` | `CHAR(1)` | N | N | N |  | IC_ATIVO IN ('S','N') | Indicador que informa se o domínio está ativo para uso no SIADL, com S para ativo e N para inativo. | Não excluir domínio historicamente utilizado. |
| `DH_INCLUSAO_REGISTRO` | `DATETIME2(3)` | N | N | N |  |  | Data e hora em que o registro foi incluído na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `DH_ALTERACAO_REGISTRO` | `DATETIME2(3)` | S | N | N |  |  | Data e hora da última alteração do registro na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `CO_USUARIO_INCLUSAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela inclusão do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `CO_USUARIO_ALTERACAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela última alteração do registro. | Preencher conforme padrão de auditoria da aplicação. |

### SDLTB020_SISTEMA_OPERACIONAL — SISTEMA_OPERACIONAL

Domínio dos sistemas operacionais associados aos dispositivos de cliente.

| Coluna | Tipo | Nulo | PK | Identity | FK | Check | Comentário | Notes |
|---|---|---|---|---|---|---|---|---|
| `CO_SISTEMA_OPERACIONAL` | `TINYINT` | N | S | N |  |  | Código que identifica univocamente o domínio sistema operacional no SIADL. | Domínio controlado pelo AD. |
| `NO_SISTEMA_OPERACIONAL` | `VARCHAR(80)` | N | N | N |  |  | Nome do domínio sistema operacional, utilizado para apresentação e entendimento negocial. | Nome sem ambiguidade e alinhado ao glossário. |
| `DE_SISTEMA_OPERACIONAL` | `VARCHAR(300)` | S | N | N |  |  | Descrição complementar do domínio sistema operacional, com finalidade, restrições e exemplos quando necessário. | Evitar tautologia. |
| `IC_ATIVO` | `CHAR(1)` | N | N | N |  | IC_ATIVO IN ('S','N') | Indicador que informa se o domínio está ativo para uso no SIADL, com S para ativo e N para inativo. | Não excluir domínio historicamente utilizado. |
| `DH_INCLUSAO_REGISTRO` | `DATETIME2(3)` | N | N | N |  |  | Data e hora em que o registro foi incluído na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `DH_ALTERACAO_REGISTRO` | `DATETIME2(3)` | S | N | N |  |  | Data e hora da última alteração do registro na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `CO_USUARIO_INCLUSAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela inclusão do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `CO_USUARIO_ALTERACAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela última alteração do registro. | Preencher conforme padrão de auditoria da aplicação. |

### SDLTB021_TIPO_LIMITE — TIPO_LIMITE

Domínio dos tipos de limite operacional de conta.

| Coluna | Tipo | Nulo | PK | Identity | FK | Check | Comentário | Notes |
|---|---|---|---|---|---|---|---|---|
| `CO_TIPO_LIMITE` | `TINYINT` | N | S | N |  |  | Código que identifica univocamente o domínio tipo limite no SIADL. | Domínio controlado pelo AD. |
| `NO_TIPO_LIMITE` | `VARCHAR(80)` | N | N | N |  |  | Nome do domínio tipo limite, utilizado para apresentação e entendimento negocial. | Nome sem ambiguidade e alinhado ao glossário. |
| `DE_TIPO_LIMITE` | `VARCHAR(300)` | S | N | N |  |  | Descrição complementar do domínio tipo limite, com finalidade, restrições e exemplos quando necessário. | Evitar tautologia. |
| `IC_ATIVO` | `CHAR(1)` | N | N | N |  | IC_ATIVO IN ('S','N') | Indicador que informa se o domínio está ativo para uso no SIADL, com S para ativo e N para inativo. | Não excluir domínio historicamente utilizado. |
| `DH_INCLUSAO_REGISTRO` | `DATETIME2(3)` | N | N | N |  |  | Data e hora em que o registro foi incluído na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `DH_ALTERACAO_REGISTRO` | `DATETIME2(3)` | S | N | N |  |  | Data e hora da última alteração do registro na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `CO_USUARIO_INCLUSAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela inclusão do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `CO_USUARIO_ALTERACAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela última alteração do registro. | Preencher conforme padrão de auditoria da aplicação. |

### SDLTB022_ORIGEM_EVENTO — ORIGEM_EVENTO

Domínio das origens de eventos registrados no histórico de transações.

| Coluna | Tipo | Nulo | PK | Identity | FK | Check | Comentário | Notes |
|---|---|---|---|---|---|---|---|---|
| `CO_ORIGEM_EVENTO` | `TINYINT` | N | S | N |  |  | Código que identifica univocamente o domínio origem evento no SIADL. | Domínio controlado pelo AD. |
| `NO_ORIGEM_EVENTO` | `VARCHAR(80)` | N | N | N |  |  | Nome do domínio origem evento, utilizado para apresentação e entendimento negocial. | Nome sem ambiguidade e alinhado ao glossário. |
| `DE_ORIGEM_EVENTO` | `VARCHAR(300)` | S | N | N |  |  | Descrição complementar do domínio origem evento, com finalidade, restrições e exemplos quando necessário. | Evitar tautologia. |
| `IC_ATIVO` | `CHAR(1)` | N | N | N |  | IC_ATIVO IN ('S','N') | Indicador que informa se o domínio está ativo para uso no SIADL, com S para ativo e N para inativo. | Não excluir domínio historicamente utilizado. |
| `DH_INCLUSAO_REGISTRO` | `DATETIME2(3)` | N | N | N |  |  | Data e hora em que o registro foi incluído na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `DH_ALTERACAO_REGISTRO` | `DATETIME2(3)` | S | N | N |  |  | Data e hora da última alteração do registro na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `CO_USUARIO_INCLUSAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela inclusão do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `CO_USUARIO_ALTERACAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela última alteração do registro. | Preencher conforme padrão de auditoria da aplicação. |

### SDLTB023_TIPO_CANAL — TIPO_CANAL

Domínio dos tipos de canal utilizados para classificar os canais do SIADL.

| Coluna | Tipo | Nulo | PK | Identity | FK | Check | Comentário | Notes |
|---|---|---|---|---|---|---|---|---|
| `CO_TIPO_CANAL` | `TINYINT` | N | S | N |  |  | Código que identifica univocamente o domínio tipo canal no SIADL. | Domínio controlado pelo AD. |
| `NO_TIPO_CANAL` | `VARCHAR(80)` | N | N | N |  |  | Nome do domínio tipo canal, utilizado para apresentação e entendimento negocial. | Nome sem ambiguidade e alinhado ao glossário. |
| `DE_TIPO_CANAL` | `VARCHAR(300)` | S | N | N |  |  | Descrição complementar do domínio tipo canal, com finalidade, restrições e exemplos quando necessário. | Evitar tautologia. |
| `IC_ATIVO` | `CHAR(1)` | N | N | N |  | IC_ATIVO IN ('S','N') | Indicador que informa se o domínio está ativo para uso no SIADL, com S para ativo e N para inativo. | Não excluir domínio historicamente utilizado. |
| `DH_INCLUSAO_REGISTRO` | `DATETIME2(3)` | N | N | N |  |  | Data e hora em que o registro foi incluído na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `DH_ALTERACAO_REGISTRO` | `DATETIME2(3)` | S | N | N |  |  | Data e hora da última alteração do registro na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `CO_USUARIO_INCLUSAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela inclusão do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `CO_USUARIO_ALTERACAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela última alteração do registro. | Preencher conforme padrão de auditoria da aplicação. |

### SDLTB024_SITUACAO_CANAL — SITUACAO_CANAL

Domínio das situações de canal utilizadas no controle de canais ativos e inativos.

| Coluna | Tipo | Nulo | PK | Identity | FK | Check | Comentário | Notes |
|---|---|---|---|---|---|---|---|---|
| `CO_SITUACAO_CANAL` | `TINYINT` | N | S | N |  |  | Código que identifica univocamente o domínio situacao canal no SIADL. | Domínio controlado pelo AD. |
| `NO_SITUACAO_CANAL` | `VARCHAR(80)` | N | N | N |  |  | Nome do domínio situacao canal, utilizado para apresentação e entendimento negocial. | Nome sem ambiguidade e alinhado ao glossário. |
| `DE_SITUACAO_CANAL` | `VARCHAR(300)` | S | N | N |  |  | Descrição complementar do domínio situacao canal, com finalidade, restrições e exemplos quando necessário. | Evitar tautologia. |
| `IC_ATIVO` | `CHAR(1)` | N | N | N |  | IC_ATIVO IN ('S','N') | Indicador que informa se o domínio está ativo para uso no SIADL, com S para ativo e N para inativo. | Não excluir domínio historicamente utilizado. |
| `DH_INCLUSAO_REGISTRO` | `DATETIME2(3)` | N | N | N |  |  | Data e hora em que o registro foi incluído na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `DH_ALTERACAO_REGISTRO` | `DATETIME2(3)` | S | N | N |  |  | Data e hora da última alteração do registro na base de dados do SIADL. | Coluna técnica de rastreabilidade. |
| `CO_USUARIO_INCLUSAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela inclusão do registro. | Preencher conforme padrão de auditoria da aplicação. |
| `CO_USUARIO_ALTERACAO` | `VARCHAR(20)` | S | N | N |  |  | Código do usuário, matrícula, serviço ou componente responsável pela última alteração do registro. | Preencher conforme padrão de auditoria da aplicação. |

## 3. Relacionamentos

| FK Name | Child Table | Child Columns | Parent Table | Parent Columns | Comment |
|---|---|---|---|---|---|
| `FK_SDLTB001_SDLTB017` | `SDLTB001_CLIENTE` | `CO_SITUACAO_CLIENTE` | `SDLTB017_SITUACAO_CLIENTE` | `CO_SITUACAO_CLIENTE` | Cliente possui situação cadastral controlada por domínio. |
| `FK_SDLTB001_SDLTB018` | `SDLTB001_CLIENTE` | `CO_SEGMENTO_CLIENTE` | `SDLTB018_SEGMENTO_CLIENTE` | `CO_SEGMENTO_CLIENTE` | Cliente possui segmento controlado por domínio. |
| `FK_SDLTB002_SDLTB001` | `SDLTB002_CONTA` | `NU_CLIENTE` | `SDLTB001_CLIENTE` | `NU_CLIENTE` | Conta pertence a cliente. |
| `FK_SDLTB002_SDLTB015` | `SDLTB002_CONTA` | `CO_TIPO_CONTA` | `SDLTB015_TIPO_CONTA` | `CO_TIPO_CONTA` | Conta possui tipo controlado por domínio. |
| `FK_SDLTB002_SDLTB016` | `SDLTB002_CONTA` | `CO_SITUACAO_CONTA` | `SDLTB016_SITUACAO_CONTA` | `CO_SITUACAO_CONTA` | Conta possui situação controlada por domínio. |
| `FK_SDLTB003_SDLTB023` | `SDLTB003_CANAL` | `CO_TIPO_CANAL` | `SDLTB023_TIPO_CANAL` | `CO_TIPO_CANAL` | Canal possui tipo controlado por domínio. |
| `FK_SDLTB003_SDLTB024` | `SDLTB003_CANAL` | `CO_SITUACAO_CANAL` | `SDLTB024_SITUACAO_CANAL` | `CO_SITUACAO_CANAL` | Canal possui situação controlada por domínio. |
| `FK_SDLTB004_SDLTB001` | `SDLTB004_ATENDIMENTO` | `NU_CLIENTE` | `SDLTB001_CLIENTE` | `NU_CLIENTE` | Atendimento é aberto por cliente. |
| `FK_SDLTB004_SDLTB003` | `SDLTB004_ATENDIMENTO` | `NU_CANAL` | `SDLTB003_CANAL` | `NU_CANAL` | Atendimento é originado por canal. |
| `FK_SDLTB004_SDLTB012` | `SDLTB004_ATENDIMENTO` | `CO_TIPO_ATENDIMENTO` | `SDLTB012_TIPO_ATENDIMENTO` | `CO_TIPO_ATENDIMENTO` | Atendimento possui tipo controlado por domínio. |
| `FK_SDLTB004_SDLTB013` | `SDLTB004_ATENDIMENTO` | `CO_SITUACAO_ATENDIMENTO` | `SDLTB013_SITUACAO_ATENDIMENTO` | `CO_SITUACAO_ATENDIMENTO` | Atendimento possui situação controlada por domínio. |
| `FK_SDLTB004_SDLTB014` | `SDLTB004_ATENDIMENTO` | `CO_PRIORIDADE_ATENDIMENTO` | `SDLTB014_PRIORIDADE_ATEND` | `CO_PRIORIDADE_ATENDIMENTO` | Atendimento possui prioridade controlada por domínio. |
| `FK_SDLTB005_SDLTB004` | `SDLTB005_INTERACAO_ATEND` | `DH_ABERTURA, NU_ATENDIMENTO` | `SDLTB004_ATENDIMENTO` | `DH_ABERTURA, NU_ATENDIMENTO` | Interação pertence a atendimento. |
| `FK_SDLTB006_SDLTB002` | `SDLTB006_TRANSACAO` | `NU_CONTA` | `SDLTB002_CONTA` | `NU_CONTA` | Transação é realizada em conta. |
| `FK_SDLTB006_SDLTB003` | `SDLTB006_TRANSACAO` | `NU_CANAL` | `SDLTB003_CANAL` | `NU_CANAL` | Transação é originada por canal. |
| `FK_SDLTB006_SDLTB010` | `SDLTB006_TRANSACAO` | `CO_TIPO_TRANSACAO` | `SDLTB010_TIPO_TRANSACAO` | `CO_TIPO_TRANSACAO` | Transação possui tipo controlado por domínio. |
| `FK_SDLTB006_SDLTB011` | `SDLTB006_TRANSACAO` | `CO_SITUACAO_TRANSACAO` | `SDLTB011_SITUACAO_TRANSACAO` | `CO_SITUACAO_TRANSACAO` | Transação possui situação corrente controlada por domínio. |
| `FK_SDLTB006_SDLTB006_1` | `SDLTB006_TRANSACAO` | `DH_TRANSACAO_ORIGINAL, NU_TRANSACAO_ORIGINAL` | `SDLTB006_TRANSACAO` | `DH_TRANSACAO, NU_TRANSACAO` | Estorno, ajuste ou reversão pode referenciar a transação original. |
| `FK_SDLTB007_SDLTB006` | `SDLTB007_TRANSACAO_HISTORICO` | `DH_TRANSACAO, NU_TRANSACAO` | `SDLTB006_TRANSACAO` | `DH_TRANSACAO, NU_TRANSACAO` | Histórico pertence a transação. |
| `FK_SDLTB007_SDLTB011_1` | `SDLTB007_TRANSACAO_HISTORICO` | `CO_SITUACAO_ANTERIOR` | `SDLTB011_SITUACAO_TRANSACAO` | `CO_SITUACAO_TRANSACAO` | Situação anterior do evento histórico. |
| `FK_SDLTB007_SDLTB011_2` | `SDLTB007_TRANSACAO_HISTORICO` | `CO_SITUACAO_NOVA` | `SDLTB011_SITUACAO_TRANSACAO` | `CO_SITUACAO_TRANSACAO` | Situação nova do evento histórico. |
| `FK_SDLTB007_SDLTB022` | `SDLTB007_TRANSACAO_HISTORICO` | `CO_ORIGEM_EVENTO` | `SDLTB022_ORIGEM_EVENTO` | `CO_ORIGEM_EVENTO` | Histórico possui origem de evento controlada por domínio. |
| `FK_SDLTB008_SDLTB001` | `SDLTB008_DISPOSITIVO_CLIENTE` | `NU_CLIENTE` | `SDLTB001_CLIENTE` | `NU_CLIENTE` | Dispositivo é vinculado a cliente. |
| `FK_SDLTB008_SDLTB019` | `SDLTB008_DISPOSITIVO_CLIENTE` | `CO_TIPO_DISPOSITIVO` | `SDLTB019_TIPO_DISPOSITIVO` | `CO_TIPO_DISPOSITIVO` | Dispositivo possui tipo controlado por domínio. |
| `FK_SDLTB008_SDLTB020` | `SDLTB008_DISPOSITIVO_CLIENTE` | `CO_SISTEMA_OPERACIONAL` | `SDLTB020_SISTEMA_OPERACIONAL` | `CO_SISTEMA_OPERACIONAL` | Dispositivo possui sistema operacional controlado por domínio. |
| `FK_SDLTB009_SDLTB002` | `SDLTB009_LIMITE_CONTA` | `NU_CONTA` | `SDLTB002_CONTA` | `NU_CONTA` | Limite pertence a conta. |
| `FK_SDLTB009_SDLTB021` | `SDLTB009_LIMITE_CONTA` | `CO_TIPO_LIMITE` | `SDLTB021_TIPO_LIMITE` | `CO_TIPO_LIMITE` | Limite possui tipo controlado por domínio. |

## 4. Chaves e índices

| Index/Key Name | Table Code | Type | Columns | Unique | Filter | Purpose |
|---|---|---|---|---|---|---|
| `PK_SDLTB001` | `SDLTB001_CLIENTE` | PRIMARY KEY | `NU_CLIENTE` | S |  | Garantir unicidade e integridade referencial da tabela. |
| `PK_SDLTB002` | `SDLTB002_CONTA` | PRIMARY KEY | `NU_CONTA` | S |  | Garantir unicidade e integridade referencial da tabela. |
| `PK_SDLTB003` | `SDLTB003_CANAL` | PRIMARY KEY | `NU_CANAL` | S |  | Garantir unicidade e integridade referencial da tabela. |
| `PK_SDLTB004` | `SDLTB004_ATENDIMENTO` | PRIMARY KEY | `DH_ABERTURA, NU_ATENDIMENTO` | S |  | Garantir unicidade e integridade referencial da tabela. |
| `PK_SDLTB005` | `SDLTB005_INTERACAO_ATEND` | PRIMARY KEY | `DH_INTERACAO, NU_INTERACAO_ATENDIMENTO` | S |  | Garantir unicidade e integridade referencial da tabela. |
| `PK_SDLTB006` | `SDLTB006_TRANSACAO` | PRIMARY KEY | `DH_TRANSACAO, NU_TRANSACAO` | S |  | Garantir unicidade e integridade referencial da tabela. |
| `PK_SDLTB007` | `SDLTB007_TRANSACAO_HISTORICO` | PRIMARY KEY | `DH_EVENTO, NU_TRANSACAO_HISTORICO` | S |  | Garantir unicidade e integridade referencial da tabela. |
| `PK_SDLTB008` | `SDLTB008_DISPOSITIVO_CLIENTE` | PRIMARY KEY | `NU_DISPOSITIVO_CLIENTE` | S |  | Garantir unicidade e integridade referencial da tabela. |
| `PK_SDLTB009` | `SDLTB009_LIMITE_CONTA` | PRIMARY KEY | `DT_INICIO_VIGENCIA, NU_LIMITE_CONTA` | S |  | Garantir unicidade e integridade referencial da tabela. |
| `PK_SDLTB010` | `SDLTB010_TIPO_TRANSACAO` | PRIMARY KEY | `CO_TIPO_TRANSACAO` | S |  | Garantir unicidade e integridade referencial da tabela. |
| `PK_SDLTB011` | `SDLTB011_SITUACAO_TRANSACAO` | PRIMARY KEY | `CO_SITUACAO_TRANSACAO` | S |  | Garantir unicidade e integridade referencial da tabela. |
| `PK_SDLTB012` | `SDLTB012_TIPO_ATENDIMENTO` | PRIMARY KEY | `CO_TIPO_ATENDIMENTO` | S |  | Garantir unicidade e integridade referencial da tabela. |
| `PK_SDLTB013` | `SDLTB013_SITUACAO_ATENDIMENTO` | PRIMARY KEY | `CO_SITUACAO_ATENDIMENTO` | S |  | Garantir unicidade e integridade referencial da tabela. |
| `PK_SDLTB014` | `SDLTB014_PRIORIDADE_ATEND` | PRIMARY KEY | `CO_PRIORIDADE_ATENDIMENTO` | S |  | Garantir unicidade e integridade referencial da tabela. |
| `PK_SDLTB015` | `SDLTB015_TIPO_CONTA` | PRIMARY KEY | `CO_TIPO_CONTA` | S |  | Garantir unicidade e integridade referencial da tabela. |
| `PK_SDLTB016` | `SDLTB016_SITUACAO_CONTA` | PRIMARY KEY | `CO_SITUACAO_CONTA` | S |  | Garantir unicidade e integridade referencial da tabela. |
| `PK_SDLTB017` | `SDLTB017_SITUACAO_CLIENTE` | PRIMARY KEY | `CO_SITUACAO_CLIENTE` | S |  | Garantir unicidade e integridade referencial da tabela. |
| `PK_SDLTB018` | `SDLTB018_SEGMENTO_CLIENTE` | PRIMARY KEY | `CO_SEGMENTO_CLIENTE` | S |  | Garantir unicidade e integridade referencial da tabela. |
| `PK_SDLTB019` | `SDLTB019_TIPO_DISPOSITIVO` | PRIMARY KEY | `CO_TIPO_DISPOSITIVO` | S |  | Garantir unicidade e integridade referencial da tabela. |
| `PK_SDLTB020` | `SDLTB020_SISTEMA_OPERACIONAL` | PRIMARY KEY | `CO_SISTEMA_OPERACIONAL` | S |  | Garantir unicidade e integridade referencial da tabela. |
| `PK_SDLTB021` | `SDLTB021_TIPO_LIMITE` | PRIMARY KEY | `CO_TIPO_LIMITE` | S |  | Garantir unicidade e integridade referencial da tabela. |
| `PK_SDLTB022` | `SDLTB022_ORIGEM_EVENTO` | PRIMARY KEY | `CO_ORIGEM_EVENTO` | S |  | Garantir unicidade e integridade referencial da tabela. |
| `PK_SDLTB023` | `SDLTB023_TIPO_CANAL` | PRIMARY KEY | `CO_TIPO_CANAL` | S |  | Garantir unicidade e integridade referencial da tabela. |
| `PK_SDLTB024` | `SDLTB024_SITUACAO_CANAL` | PRIMARY KEY | `CO_SITUACAO_CANAL` | S |  | Garantir unicidade e integridade referencial da tabela. |
| `AK_SDLTB001_1` | `SDLTB001_CLIENTE` | UNIQUE | `IC_TIPO_PESSOA, CO_CPF_CNPJ` | S |  | Garantir unicidade do identificador fiscal por tipo de pessoa, preservando compatibilidade com coluna única e suportando CNPJ alfanumérico sem função no predicado de pesquisa. |
| `IX_SDLTB001_01` | `SDLTB001_CLIENTE` | INDEX | `CO_SITUACAO_CLIENTE, CO_SEGMENTO_CLIENTE` | N |  | Apoiar consultas cadastrais por situação e segmento. |
| `AK_SDLTB002_1` | `SDLTB002_CONTA` | UNIQUE | `NU_CONTA_BANCARIA` | S |  | Garantir unicidade do número negocial da conta. |
| `IX_SDLTB002_01` | `SDLTB002_CONTA` | INDEX | `NU_CLIENTE, CO_SITUACAO_CONTA` | N |  | Apoiar consultas de contas por cliente e situação. |
| `IX_SDLTB004_01` | `SDLTB004_ATENDIMENTO` | INDEX | `NU_CLIENTE, DH_ABERTURA DESC` | N |  | Apoiar consulta de atendimentos por cliente e período. |
| `IX_SDLTB004_02` | `SDLTB004_ATENDIMENTO` | FILTERED INDEX | `CO_SITUACAO_ATENDIMENTO, DH_ABERTURA` | N | DH_FECHAMENTO IS NULL | Apoiar fila operacional de atendimentos em aberto. |
| `IX_SDLTB005_01` | `SDLTB005_INTERACAO_ATEND` | INDEX | `DH_ABERTURA, NU_ATENDIMENTO, DH_INTERACAO` | N |  | Apoiar recuperação ordenada das interações de um atendimento. |
| `IX_SDLTB006_01` | `SDLTB006_TRANSACAO` | INDEX | `NU_CONTA, DH_TRANSACAO DESC` | N |  | Apoiar consulta de extrato por conta e período. |
| `IX_SDLTB006_02` | `SDLTB006_TRANSACAO` | INDEX | `CO_SITUACAO_TRANSACAO, DH_TRANSACAO` | N |  | Apoiar consultas operacionais por situação da transação. |
| `IX_SDLTB007_01` | `SDLTB007_TRANSACAO_HISTORICO` | INDEX | `DH_TRANSACAO, NU_TRANSACAO, DH_EVENTO` | N |  | Apoiar recuperação da trilha histórica de uma transação. |
| `IX_SDLTB008_01` | `SDLTB008_DISPOSITIVO_CLIENTE` | INDEX | `NU_CLIENTE, IC_DISPOSITIVO_ATIVO` | N |  | Apoiar consulta de dispositivos ativos por cliente. |
| `AK_SDLTB008_1` | `SDLTB008_DISPOSITIVO_CLIENTE` | UNIQUE | `CO_HASH_DISPOSITIVO` | S |  | Evitar duplicidade de hash de dispositivo quando a regra de negócio assim exigir. |
| `IX_SDLTB009_01` | `SDLTB009_LIMITE_CONTA` | UNIQUE FILTERED INDEX | `NU_CONTA, CO_TIPO_LIMITE` | S | DT_FIM_VIGENCIA IS NULL | Garantir no máximo um limite vigente por conta e tipo. |
| `IX_SDLTB009_02` | `SDLTB009_LIMITE_CONTA` | INDEX | `NU_CONTA, CO_TIPO_LIMITE, DT_INICIO_VIGENCIA DESC` | N |  | Apoiar consulta do histórico de limites por conta e tipo. |
| `IX_SDLTB001_02` | `SDLTB001_CLIENTE` | NONCLUSTERED INDEX | `IC_TIPO_PESSOA, CO_CPF_CNPJ` | N |  | Apoiar consultas por tipo de pessoa e identificador fiscal normalizado sem uso de funções no predicado. |

## 5. Check constraints

| Constraint Name | Table Code | Type | Columns | Expression | Purpose |
|---|---|---|---|---|---|
| `CC_SDLTB001_1` | `SDLTB001_CLIENTE` | COLUMN CHECK | `IC_TIPO_PESSOA` | `IC_TIPO_PESSOA IN ('F','J')` | Restringir o tipo de pessoa aos valores de domínio físico PF/PJ. |
| `CT_SDLTB001_1` | `SDLTB001_CLIENTE` | TABLE CHECK | `IC_TIPO_PESSOA, CO_CPF_CNPJ` | `((IC_TIPO_PESSOA = 'F' AND CO_CPF_CNPJ NOT LIKE '%[^0-9]%') OR (IC_TIPO_PESSOA = 'J' AND CO_CPF_CNPJ NOT LIKE '%[^0-9A-Z]%'))` | Garantir identificador fiscal em coluna única: CPF numérico normalizado em 14 posições para pessoa física e CNPJ alfanumérico em 14 posições para pessoa jurídica, conforme orientação GECPA10. |
| `CC_SDLTB006_1` | `SDLTB006_TRANSACAO` | COLUMN CHECK | `VR_TRANSACAO` | `VR_TRANSACAO > 0` | Impedir valor transacional nulo ou negativo; estorno é tratado como evento próprio. |
| `CC_SDLTB008_1` | `SDLTB008_DISPOSITIVO_CLIENTE` | COLUMN CHECK | `IC_DISPOSITIVO_ATIVO` | `IC_DISPOSITIVO_ATIVO IN ('S','N')` | Controlar indicador lógico de dispositivo ativo. |
| `CC_SDLTB009_1` | `SDLTB009_LIMITE_CONTA` | COLUMN CHECK | `VR_LIMITE` | `VR_LIMITE >= 0` | Impedir limite negativo. |
| `CC_SDLTB010_1` | `SDLTB010_TIPO_TRANSACAO` | COLUMN CHECK | `IC_ATIVO` | `IC_ATIVO IN ('S','N')` | Controlar indicador lógico de registro ativo. |
| `CC_SDLTB011_1` | `SDLTB011_SITUACAO_TRANSACAO` | COLUMN CHECK | `IC_ATIVO` | `IC_ATIVO IN ('S','N')` | Controlar indicador lógico de registro ativo. |
| `CC_SDLTB012_1` | `SDLTB012_TIPO_ATENDIMENTO` | COLUMN CHECK | `IC_ATIVO` | `IC_ATIVO IN ('S','N')` | Controlar indicador lógico de registro ativo. |
| `CC_SDLTB013_1` | `SDLTB013_SITUACAO_ATENDIMENTO` | COLUMN CHECK | `IC_ATIVO` | `IC_ATIVO IN ('S','N')` | Controlar indicador lógico de registro ativo. |
| `CC_SDLTB014_1` | `SDLTB014_PRIORIDADE_ATEND` | COLUMN CHECK | `IC_ATIVO` | `IC_ATIVO IN ('S','N')` | Controlar indicador lógico de registro ativo. |
| `CC_SDLTB015_1` | `SDLTB015_TIPO_CONTA` | COLUMN CHECK | `IC_ATIVO` | `IC_ATIVO IN ('S','N')` | Controlar indicador lógico de registro ativo. |
| `CC_SDLTB016_1` | `SDLTB016_SITUACAO_CONTA` | COLUMN CHECK | `IC_ATIVO` | `IC_ATIVO IN ('S','N')` | Controlar indicador lógico de registro ativo. |
| `CC_SDLTB017_1` | `SDLTB017_SITUACAO_CLIENTE` | COLUMN CHECK | `IC_ATIVO` | `IC_ATIVO IN ('S','N')` | Controlar indicador lógico de registro ativo. |
| `CC_SDLTB018_1` | `SDLTB018_SEGMENTO_CLIENTE` | COLUMN CHECK | `IC_ATIVO` | `IC_ATIVO IN ('S','N')` | Controlar indicador lógico de registro ativo. |
| `CC_SDLTB019_1` | `SDLTB019_TIPO_DISPOSITIVO` | COLUMN CHECK | `IC_ATIVO` | `IC_ATIVO IN ('S','N')` | Controlar indicador lógico de registro ativo. |
| `CC_SDLTB020_1` | `SDLTB020_SISTEMA_OPERACIONAL` | COLUMN CHECK | `IC_ATIVO` | `IC_ATIVO IN ('S','N')` | Controlar indicador lógico de registro ativo. |
| `CC_SDLTB021_1` | `SDLTB021_TIPO_LIMITE` | COLUMN CHECK | `IC_ATIVO` | `IC_ATIVO IN ('S','N')` | Controlar indicador lógico de registro ativo. |
| `CC_SDLTB022_1` | `SDLTB022_ORIGEM_EVENTO` | COLUMN CHECK | `IC_ATIVO` | `IC_ATIVO IN ('S','N')` | Controlar indicador lógico de registro ativo. |
| `CC_SDLTB023_1` | `SDLTB023_TIPO_CANAL` | COLUMN CHECK | `IC_ATIVO` | `IC_ATIVO IN ('S','N')` | Controlar indicador lógico de registro ativo. |
| `CC_SDLTB024_1` | `SDLTB024_SITUACAO_CANAL` | COLUMN CHECK | `IC_ATIVO` | `IC_ATIVO IN ('S','N')` | Controlar indicador lógico de registro ativo. |
| `CT_SDLTB004_DH_FECHAMENTO` | `SDLTB004_ATENDIMENTO` | TABLE CHECK | `DH_FECHAMENTO, DH_ABERTURA` | `DH_FECHAMENTO IS NULL OR DH_FECHAMENTO >= DH_ABERTURA` | Garantir coerência temporal entre abertura e fechamento do atendimento. |
| `CT_SDLTB008_DT_REVOGACAO` | `SDLTB008_DISPOSITIVO_CLIENTE` | TABLE CHECK | `DT_REVOGACAO, DT_VINCULO` | `DT_REVOGACAO IS NULL OR DT_REVOGACAO >= DT_VINCULO` | Garantir coerência temporal entre vínculo e revogação do dispositivo. |
| `CT_SDLTB009_DT_FIM_VIGENCIA` | `SDLTB009_LIMITE_CONTA` | TABLE CHECK | `DT_FIM_VIGENCIA, DT_INICIO_VIGENCIA` | `DT_FIM_VIGENCIA IS NULL OR DT_FIM_VIGENCIA > DT_INICIO_VIGENCIA` | Garantir coerência temporal da vigência do limite. |

## 6. Checklist de validação CAIXA/GECPA

| Item | Orientação | Obrigatoriedade |
|---|---|---|
| Alias do sistema | Confirmar alias oficial do SIADL no PowerDesigner e substituir SDL se necessário. | Obrigatório |
| Nome lógico | Manter em português, singular, sem abreviação quando houver espaço. | Obrigatório |
| Código físico | Manter em maiúsculas, com underscore e até 30 caracteres. | Obrigatório |
| Glossário | Validar todos os termos e abreviações no glossário de termos do PowerDesigner. | Obrigatório |
| Comentários | Preencher comentário de tabela e coluna sem tautologia, com finalidade, restrição e exemplo quando útil. | Obrigatório |
| Classificação da informação | Classificar modelo, tabelas e colunas no PowerDesigner conforme grau de sigilo e LGPD. | Obrigatório |
| Volumetria | Informar quantidade estimada de ocorrências e taxa de crescimento por tabela. | Obrigatório |
| Relacionamentos | Informar cardinalidade, opcionalidade, role names e regra de deleção. | Obrigatório |
| Normalização | Garantir 1FN, 2FN e 3FN, evitando atributos multivalorados, dependência parcial e transitiva. | Obrigatório |
| Domínios | Substituir texto livre por tabelas de domínio ou constraints quando aplicável. | Obrigatório |
| Particionamento | Submeter tabelas com crescimento acima de 100 milhões linhas/ano à análise da ABD. | Obrigatório |
| Compressão | Aplicar compressão conforme análise ABD; PAGE nas partições frias/mornas e ROW/quente quando justificável. | Recomendado |
| Pré-validador | Executar pré-validador e anexar relatório sem erros ou com justificativas. | Obrigatório |
| CNPJ alfanumérico | Para coluna única CPF/CNPJ herdada da DDL existente, usar classe CO e tipo CHAR(14), manter IC_TIPO_PESSOA, normalizar valor sem máscara, criar índice por IC_TIPO_PESSOA + CO_CPF_CNPJ e registrar justificativa de compatibilidade conforme orientação GECPA10. | Obrigatório |